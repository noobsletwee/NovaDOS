function bytesFrom(value) {
  if (value instanceof Uint8Array) return value;
  if (Array.isArray(value)) return new Uint8Array(value);
  if (typeof value === "string") {
    const match = value.trim().match(/^(?:0x)?([0-9a-f]{2}(?:[\s,:-]+[0-9a-f]{2})*)$/i);
    if (match) return new Uint8Array(match[1].split(/[\s,:-]+/).map((item) => parseInt(item, 16)));
    return new TextEncoder().encode(value);
  }
  return new Uint8Array();
}

export function runX86Com(input, { maxInstructions = 100000 } = {}) {
  const code = bytesFrom(input);
  const memory = new Uint8Array(0x10000);
  memory.set(code.slice(0, memory.length), 0x100);
  const registers = { ax: 0, bx: 0, cx: 0, dx: 0, sp: 0xfffe, ip: 0x100, flags: 0 };
  const output = [];
  const read8 = (address) => memory[address & 0xffff];
  const read16 = (address) => read8(address) | (read8(address + 1) << 8);
  const lo = (value) => value & 0xff;
  const hi = (value) => (value >>> 8) & 0xff;
  const setLo = (register, value) => { registers[register] = (registers[register] & 0xff00) | (value & 0xff); };
  const setHi = (register, value) => { registers[register] = ((value & 0xff) << 8) | lo(registers[register]); };
  const dosInterrupt = () => {
    const ah = hi(registers.ax);
    if (ah === 0x09) {
      let address = registers.dx;
      let text = "";
      while (read8(address) !== 0x24 && text.length < 65536) text += String.fromCharCode(read8(address++));
      output.push(text);
      return false;
    }
    if (ah === 0x02) { output.push(String.fromCharCode(lo(registers.dx))); return false; }
    if (ah === 0x4c || ah === 0x00) return true;
    output.push("INT 21h AH=" + ah.toString(16).padStart(2, "0") + " is not implemented.");
    return true;
  };
  let halted = false;
  let instructions = 0;
  while (!halted && instructions++ < maxInstructions) {
    const opcode = read8(registers.ip++);
    switch (opcode) {
      case 0x90: break;
      case 0xb0: setLo("ax", read8(registers.ip++)); break;
      case 0xb4: setHi("ax", read8(registers.ip++)); break;
      case 0xb8: registers.ax = read16(registers.ip); registers.ip += 2; break;
      case 0xbb: registers.bx = read16(registers.ip); registers.ip += 2; break;
      case 0xb9: registers.cx = read16(registers.ip); registers.ip += 2; break;
      case 0xba: registers.dx = read16(registers.ip); registers.ip += 2; break;
      case 0xcd: halted = read8(registers.ip++) === 0x20 ? true : dosInterrupt(); break;
      case 0xc3: halted = true; break;
      case 0xeb: registers.ip = (registers.ip + (read8(registers.ip++) << 24 >> 24)) & 0xffff; break;
      case 0xfe: {
        const modrm = read8(registers.ip++);
        if (modrm === 0xc0) setLo("ax", lo(registers.ax) + 1);
        else output.push("Unsupported 16-bit opcode FE/" + ((modrm >>> 3) & 7) + ".");
        break;
      }
      default:
        halted = true;
        output.push("Unsupported 16-bit opcode " + opcode.toString(16).padStart(2, "0") + " at " + ((registers.ip - 1) & 0xffff).toString(16).padStart(4, "0") + "h.");
    }
  }
  if (instructions >= maxInstructions) output.push("Nova Guard stopped the 16-bit program at the instruction limit.");
  return {
    output: output.join("\n") || "16-bit COM program finished with no output.",
    instructions,
    registers,
    bytes: code.length,
  };
}


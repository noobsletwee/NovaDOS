const jsonHeaders = {
  "cache-control": "no-store",
  "x-content-type-options": "nosniff",
};

function json(value, status = 200) {
  return Response.json(value, { status, headers: jsonHeaders });
}

function validHost(value) {
  return typeof value === "string" && /^(?=.{1,253}$)[a-z0-9.-]+$/i.test(value) && !value.includes("..");
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/network") {
      if (request.method !== "GET") return json({ error: "Network details require GET." }, 405);
      const forwarded = request.headers.get("x-forwarded-for") || "";
      const publicIp = request.headers.get("cf-connecting-ip") || forwarded.split(",")[0].trim() || "unavailable";
      return json({
        publicIp,
        country: request.headers.get("cf-ipcountry") || "unavailable",
        edge: request.headers.get("cf-ray")?.split("-")[1] || "unavailable",
        protocol: url.protocol.replace(":", "").toUpperCase(),
        host: url.host,
      });
    }

    if (url.pathname === "/api/download") {
      if (request.method !== "POST") return json({ error: "Download transport requires POST." }, 405);
      let input;
      try { input = await request.json(); } catch (_) { return json({ error: "Invalid JSON body." }, 400); }
      let target;
      try { target = new URL(input?.url); } catch (_) { return json({ error: "Invalid URL." }, 400); }
      if (!["http:", "https:"].includes(target.protocol)) return json({ error: "Only http:// and https:// links are supported." }, 400);
      if (target.username || target.password) return json({ error: "Credential-bearing URLs are not accepted." }, 400);

      let upstream;
      try { upstream = await fetch(target.href, { redirect: "follow" }); }
      catch (_) { return json({ error: "Could not reach the download server." }, 502); }
      if (!upstream.ok) return json({ error: "Download failed: HTTP " + upstream.status + " " + upstream.statusText }, upstream.status);
      const length = Number(upstream.headers.get("content-length") || 0);
      if (length > 25 * 1024 * 1024) return json({ error: "Downloads are limited to 25 MiB." }, 413);
      const body = await upstream.arrayBuffer();
      if (body.byteLength > 25 * 1024 * 1024) return json({ error: "Downloads are limited to 25 MiB." }, 413);
      const path = target.pathname.split("/").filter(Boolean).pop() || "download";
      return new Response(body, {
        headers: {
          ...jsonHeaders,
          "content-type": upstream.headers.get("content-type") || "application/octet-stream",
          "content-length": String(body.byteLength),
          "x-download-filename": decodeURIComponent(path).replace(/[\\/:*?"<>|]/g, "_"),
        },
      });
    }

    if (url.pathname === "/api/ping") {
      if (request.method !== "POST") return json({ error: "Ping transport requires POST." }, 405);
      let input;
      try { input = await request.json(); } catch (_) { return json({ error: "Invalid JSON body." }, 400); }
      if (!validHost(input?.host)) return json({ error: "Invalid host." }, 400);
      const started = Date.now();
      let response;
      let protocol = "HTTPS";
      try {
        response = await fetch("https://" + input.host + "/", { method: "HEAD", redirect: "follow" });
      } catch (_) {
        protocol = "HTTP";
        try { response = await fetch("http://" + input.host + "/", { method: "HEAD", redirect: "follow" }); }
        catch (_) { response = null; }
      }
      return json({
        reachable: Boolean(response),
        time: Date.now() - started,
        protocol,
        note: "Browser/worker runtime cannot open raw ICMP sockets; this is an HTTP reachability probe.",
      });
    }

    if (url.pathname === "/api/dns") {
      if (request.method !== "GET") return json({ error: "DNS lookup requires GET." }, 405);
      const host = url.searchParams.get("host") || "";
      if (!validHost(host)) return json({ error: "Invalid host." }, 400);
      const dnsUrl = "https://cloudflare-dns.com/dns-query?name=" + encodeURIComponent(host) + "&type=A";
      let response;
      try { response = await fetch(dnsUrl, { headers: { accept: "application/dns-json" } }); }
      catch (_) { return json({ error: "DNS resolver unavailable." }, 502); }
      if (!response.ok) return json({ error: "DNS resolver returned HTTP " + response.status }, 502);
      const data = await response.json();
      const addresses = (data.Answer || []).map((answer) => answer.data).filter((value) => /^\d{1,3}(?:\.\d{1,3}){3}$/.test(value));
      return json({ server: "cloudflare-dns.com", addresses });
    }

    return new Response("Not found", { status: 404, headers: jsonHeaders });
  },
};

# NovaDOS 1.56

NovaDOS 1.56 is a browser-based DOS-style terminal interface. This package contains the 1.56 release and its release installer.

Use `DOWNGRADE 1.5` to install the previous release, or `UPGRADE <version>` to install a newer release when one is available.

## Run locally

Serve this folder from a web server and open `index.html`. The included `server.js` provides the `/api/*` routes used by the network, DNS, ping, and download commands when deployed on a platform that supports the project's server runtime.

## GitHub Pages

GitHub Pages can serve the frontend files, but it does not run `server.js`. The terminal itself will load, while commands that require `/api/*` routes need a separate backend or hosting platform that supports the server file.

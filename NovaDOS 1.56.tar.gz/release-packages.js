export const GITHUB_RELEASE_BASE = "https://raw.githubusercontent.com/noobsletwee/NovaDOS/main/";

export const RELEASES = Object.freeze({
  "1.0": { build: 19, label: "NovaDOS 1.0", next: "1.1", previous: null },
  "1.1": { build: 24, label: "NovaDOS 1.1", next: "1.2", previous: "1.0" },
  "1.2": { build: 34, label: "NovaDOS 1.2", next: "1.22", previous: "1.1" },
  "1.22": { build: 50, label: "NovaDOS 1.22", next: "1.4", previous: "1.2" },
  "1.4": { build: 62, label: "NovaDOS 1.4", next: "1.5", previous: "1.22" },
  "1.5": { build: 93, label: "NovaDOS 1.5", next: "1.56", previous: "1.4" },
  "1.56": { build: 119, label: "NovaDOS 1.56", next: null, previous: "1.5" },
});

export const RELEASE_ORDER = Object.freeze(Object.keys(RELEASES));

export function normalizeReleaseVersion(value) {
  const raw = String(value ?? "").trim().toLowerCase().replace(/^novados\s*/, "");
  const aliases = Object.fromEntries(RELEASE_ORDER.flatMap((version) => {
    const build = RELEASES[version].build;
    return [[String(build), version], [`v${build}`, version]];
  }));
  aliases["1"] = "1.0";
  return RELEASES[raw] ? raw : aliases[raw] || null;
}

function readTarString(bytes, start, length) {
  let end = start;
  while (end < start + length && bytes[end] !== 0) end++;
  return new TextDecoder().decode(bytes.slice(start, end)).trim();
}

function parseTarArchive(bytes) {
  const files = [];
  let offset = 0;
  while (offset + 512 <= bytes.length) {
    const header = bytes.slice(offset, offset + 512);
    if (header.every((byte) => byte === 0)) break;
    const name = readTarString(header, 0, 100);
    const prefix = readTarString(header, 345, 155);
    const fullName = `${prefix ? `${prefix}/` : ""}${name}`.replace(/^\.\//, "");
    const sizeText = readTarString(header, 124, 12).replace(/\0/g, "").trim();
    const size = sizeText ? Number.parseInt(sizeText, 8) : 0;
    const type = header[156];
    const bodyStart = offset + 512;
    const body = bytes.slice(bodyStart, bodyStart + size);
    if ((type === 0 || type === 48) && fullName && !fullName.endsWith("/")) {
      files.push({ name: fullName, bytes: body });
    }
    offset = bodyStart + Math.ceil(size / 512) * 512;
  }
  return files;
}

async function gunzip(bytes) {
  if (typeof DecompressionStream === "undefined") {
    throw new Error("This browser cannot unpack GitHub release archives.");
  }
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

export async function fetchReleaseArchive(version, onProgress = () => {}) {
  const normalized = normalizeReleaseVersion(version);
  if (!normalized) throw new Error(`Unknown NovaDOS release: ${version}`);
  const filename = `NovaDOS-${normalized}.tar.gz`;
  const url = GITHUB_RELEASE_BASE + encodeURIComponent(filename);
  onProgress(`Downloading ${filename} from GitHub...`);
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) throw new Error(`GitHub returned HTTP ${response.status} for ${filename}.`);
  const compressed = new Uint8Array(await response.arrayBuffer());
  onProgress(`Unpacking ${filename}...`);
  const tar = await gunzip(compressed);
  const files = parseTarArchive(tar);
  if (!files.length) throw new Error(`${filename} did not contain any files.`);
  return { version: normalized, filename, url, files, compressedBytes: compressed.byteLength };
}
